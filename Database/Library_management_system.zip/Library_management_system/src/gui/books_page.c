#include <gtk/gtk.h>
#include "../../include/database.h"
#include "../../include/book.h"
#include "../../include/author.h"
#include "../../include/publisher.h"
#include "main_window.h"

// Global variables
GtkWidget *books_page;
GtkWidget *books_list;
GtkWidget *search_entry;
GtkListStore *books_store;
Database *db;

// Function prototypes
void create_books_page(void);
void refresh_books_list(void);
void add_book_dialog(void);
void edit_book_dialog(int book_id);
void delete_book_dialog(int book_id);
void search_books(const char *query);
void show_popup_menu(GtkWidget *treeview, GdkEventButton *event);
void on_edit_book(GtkWidget *widget, gpointer data);
void on_delete_book(GtkWidget *widget, gpointer data);

// Create books page
void create_books_page(void) {
    // Create main vertical box
    books_page = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_set_border_width(GTK_CONTAINER(books_page), 10);

    // Create toolbar
    GtkWidget *toolbar = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(books_page), toolbar, FALSE, FALSE, 0);

    // Add Book button
    GtkWidget *add_button = gtk_button_new_with_label("➕ Add Book");
    g_signal_connect(add_button, "clicked", G_CALLBACK(add_book_dialog), NULL);
    gtk_box_pack_start(GTK_BOX(toolbar), add_button, FALSE, FALSE, 0);

    // Search entry
    search_entry = gtk_search_entry_new();
    gtk_search_entry_set_placeholder_text(GTK_SEARCH_ENTRY(search_entry), "Search books...");
    g_signal_connect(search_entry, "search-changed", G_CALLBACK(search_books), NULL);
    gtk_box_pack_end(GTK_BOX(toolbar), search_entry, TRUE, TRUE, 0);

    // Create scrolled window
    GtkWidget *scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
                                 GTK_POLICY_AUTOMATIC,
                                 GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(books_page), scrolled_window, TRUE, TRUE, 0);

    // Create tree view
    books_list = gtk_tree_view_new();
    gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(books_list), TRUE);
    gtk_container_add(GTK_CONTAINER(scrolled_window), books_list);

    // Create list store
    books_store = gtk_list_store_new(7,
                                   G_TYPE_INT,    // ID
                                   G_TYPE_STRING, // Title
                                   G_TYPE_STRING, // Author
                                   G_TYPE_STRING, // Publisher
                                   G_TYPE_STRING, // ISBN
                                   G_TYPE_STRING, // Genre
                                   G_TYPE_INT);   // Year
    gtk_tree_view_set_model(GTK_TREE_VIEW(books_list), GTK_TREE_MODEL(books_store));

    // Create columns
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    // ID column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("ID", renderer, "text", 0, NULL);
    gtk_tree_view_column_set_visible(column, FALSE);
    gtk_tree_view_append_column(GTK_TREE_VIEW(books_list), column);

    // Title column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Title", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(books_list), column);

    // Author column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Author", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(books_list), column);

    // Publisher column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Publisher", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(books_list), column);

    // ISBN column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("ISBN", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(books_list), column);

    // Genre column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Genre", renderer, "text", 5, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(books_list), column);

    // Year column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Year", renderer, "text", 6, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(books_list), column);

    // Add right-click menu
    g_signal_connect(books_list, "button-press-event", G_CALLBACK(show_popup_menu), NULL);

    // Refresh the list
    refresh_books_list();
}

// Refresh books list
void refresh_books_list(void) {
    gtk_list_store_clear(books_store);

    Book *books = get_all_books(db);
    if (books != NULL) {
        for (int i = 0; books[i].id != 0; i++) {
            GtkTreeIter iter;
            gtk_list_store_append(books_store, &iter);
            gtk_list_store_set(books_store, &iter,
                             0, books[i].id,
                             1, books[i].title,
                             2, books[i].author_name,
                             3, books[i].publisher_name,
                             4, books[i].isbn,
                             5, books[i].genre,
                             6, books[i].publication_year,
                             -1);
        }
        free(books);
    }
}

// Add book dialog
void add_book_dialog(void) {
    GtkWidget *dialog = gtk_dialog_new_with_buttons("Add Book",
                                                  GTK_WINDOW(main_window),
                                                  GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                                  "Cancel",
                                                  GTK_RESPONSE_CANCEL,
                                                  "Add",
                                                  GTK_RESPONSE_ACCEPT,
                                                  NULL);

    GtkWidget *content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_container_add(GTK_CONTAINER(content_area), grid);

    // Create entry fields
    GtkWidget *title_entry = gtk_entry_new();
    GtkWidget *author_entry = gtk_entry_new();
    GtkWidget *publisher_entry = gtk_entry_new();
    GtkWidget *isbn_entry = gtk_entry_new();
    GtkWidget *genre_entry = gtk_entry_new();
    GtkWidget *year_entry = gtk_entry_new();

    // Add labels and entries to grid
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Title:"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), title_entry, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Author:"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), author_entry, 1, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Publisher:"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), publisher_entry, 1, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("ISBN:"), 0, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), isbn_entry, 1, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Genre:"), 0, 4, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), genre_entry, 1, 4, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Year:"), 0, 5, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), year_entry, 1, 5, 1, 1);

    gtk_widget_show_all(dialog);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
        Book book = {0};
        strncpy(book.title, gtk_entry_get_text(GTK_ENTRY(title_entry)), sizeof(book.title) - 1);
        strncpy(book.author_name, gtk_entry_get_text(GTK_ENTRY(author_entry)), sizeof(book.author_name) - 1);
        strncpy(book.publisher_name, gtk_entry_get_text(GTK_ENTRY(publisher_entry)), sizeof(book.publisher_name) - 1);
        strncpy(book.isbn, gtk_entry_get_text(GTK_ENTRY(isbn_entry)), sizeof(book.isbn) - 1);
        strncpy(book.genre, gtk_entry_get_text(GTK_ENTRY(genre_entry)), sizeof(book.genre) - 1);
        book.publication_year = atoi(gtk_entry_get_text(GTK_ENTRY(year_entry)));

        if (add_book(db, &book)) {
            refresh_books_list();
        } else {
            GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(dialog),
                                                           GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                                           GTK_MESSAGE_ERROR,
                                                           GTK_BUTTONS_OK,
                                                           "Failed to add book");
            gtk_dialog_run(GTK_DIALOG(error_dialog));
            gtk_widget_destroy(error_dialog);
        }
    }

    gtk_widget_destroy(dialog);
}

// Edit book dialog
void edit_book_dialog(int book_id) {
    Book book;
    if (!get_book_by_id(db, book_id, &book)) {
        return;
    }

    GtkWidget *dialog = gtk_dialog_new_with_buttons("Edit Book",
                                                  GTK_WINDOW(main_window),
                                                  GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                                  "Cancel",
                                                  GTK_RESPONSE_CANCEL,
                                                  "Save",
                                                  GTK_RESPONSE_ACCEPT,
                                                  NULL);

    GtkWidget *content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_container_add(GTK_CONTAINER(content_area), grid);

    // Create entry fields
    GtkWidget *title_entry = gtk_entry_new();
    GtkWidget *author_entry = gtk_entry_new();
    GtkWidget *publisher_entry = gtk_entry_new();
    GtkWidget *isbn_entry = gtk_entry_new();
    GtkWidget *genre_entry = gtk_entry_new();
    GtkWidget *year_entry = gtk_entry_new();

    // Set initial values
    gtk_entry_set_text(GTK_ENTRY(title_entry), book.title);
    gtk_entry_set_text(GTK_ENTRY(author_entry), book.author_name);
    gtk_entry_set_text(GTK_ENTRY(publisher_entry), book.publisher_name);
    gtk_entry_set_text(GTK_ENTRY(isbn_entry), book.isbn);
    gtk_entry_set_text(GTK_ENTRY(genre_entry), book.genre);
    char year_str[5];
    snprintf(year_str, sizeof(year_str), "%d", book.publication_year);
    gtk_entry_set_text(GTK_ENTRY(year_entry), year_str);

    // Add labels and entries to grid
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Title:"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), title_entry, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Author:"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), author_entry, 1, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Publisher:"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), publisher_entry, 1, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("ISBN:"), 0, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), isbn_entry, 1, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Genre:"), 0, 4, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), genre_entry, 1, 4, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Year:"), 0, 5, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), year_entry, 1, 5, 1, 1);

    gtk_widget_show_all(dialog);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
        strncpy(book.title, gtk_entry_get_text(GTK_ENTRY(title_entry)), sizeof(book.title) - 1);
        strncpy(book.author_name, gtk_entry_get_text(GTK_ENTRY(author_entry)), sizeof(book.author_name) - 1);
        strncpy(book.publisher_name, gtk_entry_get_text(GTK_ENTRY(publisher_entry)), sizeof(book.publisher_name) - 1);
        strncpy(book.isbn, gtk_entry_get_text(GTK_ENTRY(isbn_entry)), sizeof(book.isbn) - 1);
        strncpy(book.genre, gtk_entry_get_text(GTK_ENTRY(genre_entry)), sizeof(book.genre) - 1);
        book.publication_year = atoi(gtk_entry_get_text(GTK_ENTRY(year_entry)));

        if (update_book(db, &book)) {
            refresh_books_list();
        } else {
            GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(dialog),
                                                           GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                                           GTK_MESSAGE_ERROR,
                                                           GTK_BUTTONS_OK,
                                                           "Failed to update book");
            gtk_dialog_run(GTK_DIALOG(error_dialog));
            gtk_widget_destroy(error_dialog);
        }
    }

    gtk_widget_destroy(dialog);
}

// Delete book dialog
void delete_book_dialog(int book_id) {
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(main_window),
                                             GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                             GTK_MESSAGE_QUESTION,
                                             GTK_BUTTONS_YES_NO,
                                             "Are you sure you want to delete this book?");
    gtk_window_set_title(GTK_WINDOW(dialog), "Confirm Delete");

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_YES) {
        if (delete_book(db, book_id)) {
            refresh_books_list();
        } else {
            GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(dialog),
                                                           GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                                           GTK_MESSAGE_ERROR,
                                                           GTK_BUTTONS_OK,
                                                           "Failed to delete book");
            gtk_dialog_run(GTK_DIALOG(error_dialog));
            gtk_widget_destroy(error_dialog);
        }
    }

    gtk_widget_destroy(dialog);
}

// Search books
void search_books(const char *query) {
    gtk_list_store_clear(books_store);

    Book *books = search_books_by_title(db, query);
    if (books != NULL) {
        for (int i = 0; books[i].id != 0; i++) {
            GtkTreeIter iter;
            gtk_list_store_append(books_store, &iter);
            gtk_list_store_set(books_store, &iter,
                             0, books[i].id,
                             1, books[i].title,
                             2, books[i].author_name,
                             3, books[i].publisher_name,
                             4, books[i].isbn,
                             5, books[i].genre,
                             6, books[i].publication_year,
                             -1);
        }
        free(books);
    }
}

// Show popup menu
void show_popup_menu(GtkWidget *treeview, GdkEventButton *event) {
    if (event->type == GDK_BUTTON_PRESS && event->button == 3) {
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
        GtkTreeModel *model;
        GtkTreeIter iter;

        if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
            GtkWidget *menu = gtk_menu_new();
            GtkWidget *edit_item = gtk_menu_item_new_with_label("Edit");
            GtkWidget *delete_item = gtk_menu_item_new_with_label("Delete");

            gtk_menu_shell_append(GTK_MENU_SHELL(menu), edit_item);
            gtk_menu_shell_append(GTK_MENU_SHELL(menu), delete_item);

            g_signal_connect(edit_item, "activate", G_CALLBACK(on_edit_book), &iter);
            g_signal_connect(delete_item, "activate", G_CALLBACK(on_delete_book), &iter);

            gtk_widget_show_all(menu);
            gtk_menu_popup_at_pointer(GTK_MENU(menu), (GdkEvent *)event);
        }
    }
}

// Edit book callback
void on_edit_book(GtkWidget *widget, gpointer data) {
    GtkTreeIter *iter = (GtkTreeIter *)data;
    int book_id;
    gtk_tree_model_get(GTK_TREE_MODEL(books_store), iter, 0, &book_id, -1);
    edit_book_dialog(book_id);
}

// Delete book callback
void on_delete_book(GtkWidget *widget, gpointer data) {
    GtkTreeIter *iter = (GtkTreeIter *)data;
    int book_id;
    gtk_tree_model_get(GTK_TREE_MODEL(books_store), iter, 0, &book_id, -1);
    delete_book_dialog(book_id);
} 