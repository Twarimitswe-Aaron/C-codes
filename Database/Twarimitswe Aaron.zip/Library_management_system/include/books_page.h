#ifndef BOOKS_PAGE_H
#define BOOKS_PAGE_H

#include <gtk/gtk.h>

// Function to show the books page
void show_books_page(void);

#endif // BOOKS_PAGE_H 